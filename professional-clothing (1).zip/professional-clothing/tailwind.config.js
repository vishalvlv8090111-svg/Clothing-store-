export default {content:['./index.html','./src/**/*.{js,jsx}'],theme:{extend:{fontFamily:{display:['"Bebas Neue"','Impact','sans-serif'],sans:['Inter','system-ui','sans-serif']}}},plugins:[]};
