import React,{useEffect,useMemo,useState,lazy,Suspense} from 'react';
import {PRODUCTS,CATS,COLORS,SIZES,REVIEWS,inr} from './data';import {useStore} from './store';import ProductArt from './ProductArt';
const Garment3D=lazy(()=>import('./Garment3D'));
const Loader=()=><div className="w-full h-full grid place-items-center text-xs tracking-[.4em] text-neutral-400">LOADING 3D…</div>;
const Viewer=p=><Suspense fallback={<Loader/>}><Garment3D {...p}/></Suspense>;
function useReveal(){useEffect(()=>{const o=new IntersectionObserver(es=>es.forEach(e=>e.isIntersecting&&e.target.classList.add('in')),{threshold:.12});document.querySelectorAll('.rv').forEach(el=>o.observe(el));return()=>o.disconnect()})}
const H=({k,t})=><div className="rv mb-10"><p className="text-xs tracking-[.4em] text-neutral-500">{k}</p><h2 className="font-display text-5xl md:text-7xl silver">{t}</h2></div>;

function Card({p,onView}){const {toggleWish,wish,add}=useStore();const [c,setC]=useState('Black');
return <article className="rv group bg-neutral-900/60 border border-neutral-800 hover:border-neutral-500 transition">
<div className="relative aspect-square grid place-items-center overflow-hidden bg-gradient-to-b from-neutral-800 to-neutral-950">
<ProductArt type={p.type} color={c} className="w-3/4 transition duration-700 group-hover:scale-110"/>
{p.tag&&<span className="absolute top-3 left-3 text-[10px] tracking-widest bg-white text-black px-2 py-1">{p.tag==='new'?'NEW':'BEST SELLER'}</span>}
<button aria-label="Toggle wishlist" onClick={()=>toggleWish(p)} className="absolute top-2 right-2 w-11 h-11 text-xl">{wish.includes(p.id)?'♥':'♡'}</button>
<button onClick={()=>onView(p)} className="absolute bottom-0 inset-x-0 bg-white text-black text-xs tracking-widest py-3 md:translate-y-full group-hover:translate-y-0 transition">QUICK VIEW</button></div>
<div className="p-4"><h3 className="text-sm">{p.name}</h3><p className="text-neutral-400 text-sm mt-1">{inr(p.price)}</p>
<div className="flex gap-2 mt-3">{Object.keys(COLORS).map(k=><button key={k} aria-label={k} onClick={()=>setC(k)} className={`w-6 h-6 rounded-full border ${c===k?'ring-2 ring-white':'border-neutral-600'}`} style={{background:COLORS[k]}}/>)}</div>
<button onClick={()=>add(p,'M',c)} className="btn ghost w-full mt-4 text-[11px]">ADD TO CART (M)</button></div></article>}

function Picker({p,big}){const {add}=useStore();const [c,setC]=useState('Black');const [s,setS]=useState('M');
return <div className={big?'grid md:grid-cols-2 gap-8 items-center':'grid md:grid-cols-2 gap-6'}>
<div className={big?'h-[420px] md:h-[560px] bg-gradient-radial':'h-72 md:h-96'}>{big?Viewer({type:p.type,color:c}):<ProductArt type={p.type} color={c} className="h-full mx-auto"/>}</div>
<div><h3 className="font-display text-4xl">{p.name}</h3><p className="text-xl mt-1">{inr(p.price)}</p>
<p className="text-neutral-400 text-sm mt-3">Heavyweight, premium-feel fabric with a clean luxury streetwear cut. Drag the model to rotate.</p>
<p className="text-xs tracking-widest mt-6 mb-2">COLOR — {c.toUpperCase()}</p><div className="flex gap-3">{Object.keys(COLORS).map(k=><button key={k} aria-label={k} onClick={()=>setC(k)} className={`w-10 h-10 rounded-full border ${c===k?'ring-2 ring-white':'border-neutral-600'}`} style={{background:COLORS[k]}}/>)}</div>
<p className="text-xs tracking-widest mt-6 mb-2">SIZE</p><div className="flex flex-wrap gap-2">{SIZES.map(z=><button key={z} onClick={()=>setS(z)} aria-pressed={s===z} className={`min-w-12 h-12 border ${s===z?'bg-white text-black':'border-neutral-600'}`}>{z}</button>)}</div>
<button onClick={()=>add(p,s,c)} className="btn mt-8 w-full">ADD TO CART</button></div></div>}

function CartDrawer({open,close,checkout}){const {cart,qty,remove,subtotal}=useStore();
return <><div onClick={close} className={`fixed inset-0 bg-black/70 z-40 transition ${open?'opacity-100':'opacity-0 pointer-events-none'}`}/>
<aside aria-label="Cart" className={`fixed top-0 right-0 h-full w-full max-w-md bg-neutral-950 border-l border-neutral-800 z-50 flex flex-col transition-transform duration-500 ${open?'':'translate-x-full'}`}>
<div className="p-5 flex justify-between border-b border-neutral-800"><h2 className="font-display text-3xl">YOUR CART</h2><button onClick={close} aria-label="Close cart" className="w-11 h-11 text-2xl">×</button></div>
<div className="flex-1 overflow-y-auto p-5 space-y-5">{cart.length===0&&<p className="text-neutral-500">Your cart is empty.</p>}
{cart.map(i=><div key={i.key} className="flex gap-4"><div className="w-20 h-20 bg-neutral-900 grid place-items-center"><ProductArt type={i.type} color={i.color} className="w-14"/></div>
<div className="flex-1 text-sm"><p>{i.name}</p><p className="text-neutral-500">{i.size} · {i.color}</p><p>{inr(i.price)}</p>
<div className="flex items-center gap-3 mt-1"><button aria-label="Decrease" onClick={()=>qty(i.key,-1)} className="w-9 h-9 border border-neutral-700">−</button><span>{i.qty}</span><button aria-label="Increase" onClick={()=>qty(i.key,1)} className="w-9 h-9 border border-neutral-700">+</button><button onClick={()=>remove(i.key)} className="ml-auto text-xs underline text-neutral-400">Remove</button></div></div></div>)}</div>
<div className="p-5 border-t border-neutral-800"><div className="flex justify-between mb-4"><span>Subtotal</span><b>{inr(subtotal)}</b></div>
<button disabled={!cart.length} onClick={checkout} className="btn w-full disabled:opacity-40">CHECKOUT</button></div></aside></>}

function Checkout({back}){const {cart,subtotal,clear}=useStore();const [done,setDone]=useState(false);const ship=subtotal>=2999||!subtotal?0:149;
const inp="w-full bg-neutral-900 border border-neutral-700 p-3 text-sm";
if(done)return <main className="min-h-screen grid place-items-center text-center p-6"><div><h1 className="font-display text-6xl silver">DEMO ORDER COMPLETE</h1><p className="text-neutral-400 mt-4 max-w-md mx-auto">No real order or payment was made. Connect a backend and payment gateway (Razorpay / Stripe) to accept real orders.</p><button className="btn mt-8" onClick={()=>{clear();back()}}>BACK TO STORE</button></div></main>;
return <main className="max-w-6xl mx-auto px-5 pt-28 pb-20"><button onClick={back} className="text-xs tracking-widest text-neutral-400 mb-6">← BACK TO STORE</button><h1 className="font-display text-6xl mb-8">CHECKOUT</h1>
<div className="mb-8 border border-yellow-700/60 bg-yellow-900/20 p-4 text-sm">Demo checkout only. No payment is taken and no order is placed. A secure payment gateway and a backend (order database, server-side price validation, webhooks) must be connected before accepting real orders.</div>
<div className="grid md:grid-cols-2 gap-10"><form onSubmit={e=>{e.preventDefault();setDone(true)}} className="space-y-3">
<input required className={inp} placeholder="Full name" autoComplete="name"/><input required type="email" className={inp} placeholder="Email" autoComplete="email"/><input required type="tel" className={inp} placeholder="Phone" autoComplete="tel"/>
<input required className={inp} placeholder="Address" autoComplete="street-address"/><div className="grid grid-cols-2 gap-3"><input required className={inp} placeholder="City"/><input required className={inp} placeholder="PIN code" inputMode="numeric"/></div>
<input required className={inp} placeholder="State"/><button disabled={!cart.length} className="btn w-full mt-4 disabled:opacity-40">PLACE DEMO ORDER</button></form>
<div className="bg-neutral-900 p-6 h-fit"><h2 className="font-display text-3xl mb-4">ORDER SUMMARY</h2>{cart.map(i=><div key={i.key} className="flex justify-between text-sm py-2 border-b border-neutral-800"><span>{i.name} ({i.size}, {i.color}) ×{i.qty}</span><span>{inr(i.price*i.qty)}</span></div>)}
<p className="flex justify-between mt-4 text-sm"><span>Shipping</span><span>{ship?inr(ship):'Free'}</span></p><p className="flex justify-between mt-2 text-lg"><b>Total</b><b>{inr(subtotal+ship)}</b></p></div></div></main>}

export default function App(){
useReveal();const {count,wish,toast}=useStore();const [cat,setCat]=useState('All');const [q,setQ]=useState('');const [cartOpen,setCartOpen]=useState(false);const [quick,setQuick]=useState(null);const [view,setView]=useState('shop');const [y,setY]=useState(0);const [menu,setMenu]=useState(false);const [wo,setWo]=useState(false);
useEffect(()=>{const f=()=>setY(window.scrollY);window.addEventListener('scroll',f,{passive:true});return()=>window.removeEventListener('scroll',f)},[]);
const list=useMemo(()=>PRODUCTS.filter(p=>(cat==='All'||p.cat===cat)&&p.name.toLowerCase().includes(q.toLowerCase())&&(!wo||wish.includes(p.id))),[cat,q,wo,wish]);
const newA=list.filter(p=>p.tag==='new'),best=list.filter(p=>p.tag==='best');const go=id=>{setMenu(false);document.getElementById(id)?.scrollIntoView({behavior:'smooth'})};
const nav=[['new','New'],['best','Best Sellers'],['showcase','3D Viewer'],['about','About'],['lookbook','Lookbook']];
const Grid=({items})=>items.length?<div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-6">{items.map(p=><Card key={p.id} p={p} onView={setQuick}/>)}</div>:<p className="text-neutral-500">No products match.</p>;
return <>
<header className="fixed top-0 inset-x-0 z-30 bg-black/70 backdrop-blur border-b border-neutral-900"><div className="max-w-7xl mx-auto flex items-center gap-4 px-4 h-16">
<button onClick={()=>{setView('shop');window.scrollTo(0,0)}} className="font-display text-xl md:text-2xl tracking-[.15em]">PROFESSIONAL CLOTHING</button>
<nav className="hidden lg:flex gap-6 text-xs tracking-widest ml-8 text-neutral-400">{nav.map(([i,l])=><button key={i} onClick={()=>{setView('shop');setTimeout(()=>go(i),50)}} className="hover:text-white">{l.toUpperCase()}</button>)}</nav>
<input aria-label="Search products" value={q} onChange={e=>setQ(e.target.value)} placeholder="Search…" className="ml-auto w-28 md:w-56 bg-neutral-900 border border-neutral-800 px-3 h-10 text-sm"/>
<button aria-label="Wishlist filter" aria-pressed={wo} onClick={()=>setWo(!wo)} className="w-11 h-11">{wo?'♥':'♡'}<sup>{wish.length}</sup></button>
<button aria-label="Open cart" onClick={()=>setCartOpen(true)} className="w-11 h-11">🛍<sup>{count}</sup></button>
<button aria-label="Menu" className="lg:hidden w-11 h-11 text-xl" onClick={()=>setMenu(!menu)}>☰</button></div>
{menu&&<div className="lg:hidden flex flex-col bg-black border-t border-neutral-900">{nav.map(([i,l])=><button key={i} onClick={()=>go(i)} className="p-4 text-left text-sm tracking-widest">{l.toUpperCase()}</button>)}</div>}</header>
{view==='checkout'?<Checkout back={()=>{setView('shop');window.scrollTo(0,0)}}/>:<main>
<section className="relative h-screen min-h-[640px] overflow-hidden grid place-items-center text-center">
<div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_40%,#2a2a2e,#0a0a0a_70%)]" style={{transform:`translateY(${y*.25}px)`}}/>
<div className="absolute inset-0 opacity-90" style={{transform:`translateY(${y*.1}px)`}}>{Viewer({type:'hoodie',color:'Charcoal'})}</div>
<div className="relative z-10 px-5 pointer-events-none" style={{opacity:Math.max(0,1-y/600)}}><p className="text-xs tracking-[.5em] text-neutral-400 mb-4">PREMIUM STREETWEAR</p>
<h1 className="font-display text-[15vw] md:text-[9rem] leading-none silver">PROFESSIONAL<br/>CLOTHING</h1><p className="tracking-[.5em] mt-4">WEAR YOUR IDENTITY</p>
<button onClick={()=>go('new')} className="btn mt-10 pointer-events-auto">SHOP NOW</button><p className="text-[10px] tracking-widest text-neutral-500 mt-6">DRAG TO ROTATE</p></div></section>
<section id="new" className="max-w-7xl mx-auto px-4 py-24"><div className="flex flex-wrap gap-2 mb-10">{CATS.map(c=><button key={c} onClick={()=>setCat(c)} aria-pressed={cat===c} className={`px-4 h-11 text-xs tracking-widest border ${cat===c?'bg-white text-black':'border-neutral-700'}`}>{c.toUpperCase()}</button>)}</div>
<H k="JUST DROPPED" t="NEW ARRIVALS"/><Grid items={newA}/></section>
<section id="best" className="max-w-7xl mx-auto px-4 py-24"><H k="MOST WANTED" t="BEST SELLERS"/><Grid items={best}/></section>
<section id="showcase" className="bg-neutral-950 py-24"><div className="max-w-7xl mx-auto px-4"><H k="INTERACTIVE" t="3D PRODUCT SHOWCASE"/><Picker big p={PRODUCTS[2]}/></div></section>
<section id="about" className="max-w-5xl mx-auto px-4 py-32 text-center"><H k="OUR STORY" t="ABOUT THE BRAND"/><p className="rv text-xl md:text-3xl font-light leading-relaxed text-neutral-300">Born from the idea that what you wear is your first sentence. We build heavyweight, considered pieces in a restrained palette — black, white, charcoal and silver — made to be lived in, layered and remembered.</p></section>
<section id="lookbook" className="max-w-7xl mx-auto px-4 py-24"><H k="SEASON 01" t="LOOKBOOK"/><div className="grid grid-cols-2 md:grid-cols-4 gap-3">{['tee','hoodie','jacket','cargo','hoodie','cargo','tee','jacket'].map((t,i)=><div key={i} className={`rv relative overflow-hidden bg-gradient-to-br from-neutral-800 to-black grid place-items-center ${i%3===0?'row-span-2 aspect-[1/2]':'aspect-square'}`}><ProductArt type={t} color={['Silver','Charcoal','Black','White'][i%4]} className="w-2/3 hover:scale-110 transition duration-700"/><span className="absolute bottom-2 left-3 text-[10px] tracking-widest text-neutral-400">LOOK {String(i+1).padStart(2,'0')}</span></div>)}</div></section>
<section className="max-w-6xl mx-auto px-4 py-24"><H k="LOVED BY" t="CUSTOMER REVIEWS"/><div className="grid md:grid-cols-3 gap-6">{REVIEWS.map(([n,t])=><blockquote key={n} className="rv border border-neutral-800 p-6"><p className="text-yellow-200 mb-3">★★★★★</p><p className="text-neutral-300">“{t}”</p><footer className="mt-4 text-xs tracking-widest text-neutral-500">— {n}</footer></blockquote>)}</div></section>
<Newsletter/>
<footer className="border-t border-neutral-900 py-14 px-4"><div className="max-w-7xl mx-auto grid md:grid-cols-4 gap-8 text-sm text-neutral-400"><div><p className="font-display text-2xl text-white">PROFESSIONAL CLOTHING</p><p className="mt-2">Wear your identity.</p></div>
<div><p className="text-white mb-2">Contact</p><p>hello@professionalclothing.example</p><p>+91 00000 00000</p><a className="underline" href="https://instagram.com" target="_blank" rel="noreferrer">Instagram</a></div>
<div><p className="text-white mb-2">Shipping</p><p>Free shipping over ₹2,999. Delivery in 4–7 days.</p></div><div><p className="text-white mb-2">Policies</p><p>7-day easy returns · Privacy · Terms</p></div></div><p className="text-center text-xs text-neutral-600 mt-10">© 2026 PROFESSIONAL CLOTHING. Demo storefront.</p></footer></main>}
{quick&&<div role="dialog" aria-modal="true" className="fixed inset-0 z-50 bg-black/85 overflow-y-auto p-4"><div className="max-w-4xl mx-auto bg-neutral-950 border border-neutral-800 p-6 mt-10"><button onClick={()=>setQuick(null)} aria-label="Close" className="float-right w-11 h-11 text-2xl">×</button><Picker p={quick}/></div></div>}
<CartDrawer open={cartOpen} close={()=>setCartOpen(false)} checkout={()=>{setCartOpen(false);setView('checkout');window.scrollTo(0,0)}}/>
<div role="status" aria-live="polite" className={`fixed bottom-5 left-1/2 -translate-x-1/2 z-[60] bg-white text-black text-sm px-5 py-3 transition ${toast?'opacity-100':'opacity-0 pointer-events-none'}`}>{toast}</div></>}
function Newsletter(){const [ok,setOk]=useState(false);return <section className="bg-neutral-900 py-20 px-4 text-center"><h2 className="font-display text-5xl silver">JOIN THE LIST</h2><p className="text-neutral-400 mt-2">Early drops and private offers.</p>
{ok?<p className="mt-6">Thanks! (demo — connect an email service to store subscribers)</p>:<form onSubmit={e=>{e.preventDefault();setOk(true)}} className="mt-6 flex flex-col sm:flex-row gap-3 max-w-md mx-auto"><input required type="email" aria-label="Email" placeholder="your@email.com" className="flex-1 bg-black border border-neutral-700 px-4 h-12"/><button className="btn">SUBSCRIBE</button></form>}</section>}
