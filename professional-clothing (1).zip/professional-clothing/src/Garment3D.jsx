import React,{Suspense,Component} from 'react';import {Canvas} from '@react-three/fiber';import {OrbitControls,Float,Sparkles,RoundedBox} from '@react-three/drei';import {COLORS} from './data';import ProductArt from './ProductArt';
function Garment({type,color}){const c=COLORS[color]||color;const m=<meshStandardMaterial color={c} roughness={.85} metalness={.05}/>;const long=type==='hoodie'||type==='jacket';
return <Float speed={1.5} rotationIntensity={.15} floatIntensity={.6}><group scale={1.1}>
<RoundedBox args={[1.7,2.1,.62]} radius={.22} smoothness={4} position={[0,-.1,0]}>{m}</RoundedBox>
{[-1,1].map(s=><RoundedBox key={s} args={[long?1.5:.8,.55,.52]} radius={.2} smoothness={4} position={[s*(long?1.45:1.15),long?.15:.7,0]} rotation={[0,0,s*-(long?.9:.6)]}>{m}</RoundedBox>)}
<mesh position={[0,.98,.05]} rotation={[Math.PI/2,0,0]}><torusGeometry args={[.36,.09,12,32]}/><meshStandardMaterial color={type==='hoodie'?c:'#0a0a0a'} roughness={.9}/></mesh>
{type==='hoodie'&&<RoundedBox args={[.9,.4,.2]} radius={.12} position={[0,-.7,.34]}><meshStandardMaterial color={c} roughness={.95}/></RoundedBox>}
{type==='jacket'&&<mesh position={[0,-.1,.32]}><boxGeometry args={[.04,2,.02]}/><meshStandardMaterial color="#a9adb3" metalness={1} roughness={.3}/></mesh>}
{type==='cargo'&&null}</group></Float>}
class Boundary extends Component{state={e:false};static getDerivedStateFromError(){return{e:true}}render(){return this.state.e?this.props.fallback:this.props.children}}
export default function Garment3D({type='tee',color='Black',auto=true}){
const fb=<div className="w-full h-full grid place-items-center" style={{perspective:800}}><ProductArt type={type} color={color} className="w-3/4 max-h-full animate-pulse"/></div>;
const t=type==='cargo'?'tee':type;
return <Boundary fallback={fb}><Suspense fallback={fb}><Canvas dpr={[1,1.5]} camera={{position:[0,0,6],fov:38}} gl={{antialias:true,powerPreference:'high-performance'}} style={{touchAction:'pan-y'}}>
<ambientLight intensity={.55}/><directionalLight position={[3,4,5]} intensity={2.2}/><spotLight position={[-5,3,-3]} intensity={3} color="#9fb4ff"/><pointLight position={[0,-3,3]} intensity={.8} color="#fff"/>
<Garment type={t} color={color}/><Sparkles count={40} scale={7} size={2} speed={.3} color="#c8ccd2"/>
<OrbitControls enableZoom={false} enablePan={false} autoRotate={auto} autoRotateSpeed={2}/></Canvas></Suspense></Boundary>}
