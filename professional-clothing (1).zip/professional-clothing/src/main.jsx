import React from 'react';import {createRoot} from 'react-dom/client';import './index.css';import App from './App.jsx';import {Store} from './store.jsx';
createRoot(document.getElementById('root')).render(<Store><App/></Store>);
