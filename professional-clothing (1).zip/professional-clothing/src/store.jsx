import React,{createContext,useContext,useEffect,useState} from 'react';
const Ctx=createContext(null);export const useStore=()=>useContext(Ctx);
const load=(k,d)=>{try{return JSON.parse(localStorage.getItem(k))??d}catch{return d}};
export function Store({children}){
const [cart,setCart]=useState(()=>load('pc-cart',[]));const [wish,setWish]=useState(()=>load('pc-wish',[]));const [toast,setToast]=useState('');
useEffect(()=>{try{localStorage.setItem('pc-cart',JSON.stringify(cart))}catch{}},[cart]);
useEffect(()=>{try{localStorage.setItem('pc-wish',JSON.stringify(wish))}catch{}},[wish]);
const say=m=>{setToast(m);clearTimeout(window.__t);window.__t=setTimeout(()=>setToast(''),2200)};
const add=(p,size,color)=>{const key=`${p.id}-${size}-${color}`;setCart(c=>c.find(i=>i.key===key)?c.map(i=>i.key===key?{...i,qty:i.qty+1}:i):[...c,{key,id:p.id,name:p.name,type:p.type,price:p.price,size,color,qty:1}]);say(`Added to cart: ${p.name} (${size}, ${color})`)};
const qty=(key,d)=>setCart(c=>c.map(i=>i.key===key?{...i,qty:i.qty+d}:i).filter(i=>i.qty>0));
const remove=key=>setCart(c=>c.filter(i=>i.key!==key));
const toggleWish=p=>{setWish(w=>w.includes(p.id)?w.filter(x=>x!==p.id):[...w,p.id]);say(wish.includes(p.id)?'Removed from wishlist':'Saved to wishlist')};
const subtotal=cart.reduce((s,i)=>s+i.price*i.qty,0);const count=cart.reduce((s,i)=>s+i.qty,0);
return <Ctx.Provider value={{cart,add,qty,remove,clear:()=>setCart([]),wish,toggleWish,subtotal,count,toast,say}}>{children}</Ctx.Provider>}
