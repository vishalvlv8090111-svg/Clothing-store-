export const COLORS={Black:'#141414',White:'#ececec',Charcoal:'#3d3d40',Silver:'#a9adb3'};
export const SIZES=['S','M','L','XL','XXL'];
export const CATS=['All','T-Shirts','Hoodies','Jackets','Cargo Pants'];
const p=(id,name,cat,type,price,tag)=>({id,name,cat,type,price,tag});
export const PRODUCTS=[
p(1,'Oversized Essential Tee','T-Shirts','tee',1499,'new'),p(2,'Noir Boxy Tee','T-Shirts','tee',1299,'best'),
p(3,'Heavyweight Hoodie','Hoodies','hoodie',3499,'best'),p(4,'Shadow Zip Hoodie','Hoodies','hoodie',3999,'new'),
p(5,'Utility Track Jacket','Jackets','jacket',5499,'new'),p(6,'Silver Bomber Jacket','Jackets','jacket',6299,'best'),
p(7,'Tactical Cargo Pants','Cargo Pants','cargo',3299,'best'),p(8,'Wide Leg Cargo','Cargo Pants','cargo',3599,'new')];
export const REVIEWS=[['Aarav M.','The fabric quality feels like a luxury label. Fit is perfect.'],['Sneha K.','Best oversized hoodie I own. Heavy, soft, and sharp.'],['Rohan D.','Cargo pants have such a clean silhouette. Obsessed.']];
export const inr=n=>'₹'+n.toLocaleString('en-IN');
