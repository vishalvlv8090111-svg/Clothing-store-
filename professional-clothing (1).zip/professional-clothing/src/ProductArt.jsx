import React from 'react';import {COLORS} from './data';
const P={tee:'M30 20 L45 12 Q60 26 75 12 L90 20 L110 44 L96 54 L88 46 L88 112 L32 112 L32 46 L24 54 L10 44 Z',
hoodie:'M28 22 L46 12 Q60 30 74 12 L92 22 L112 70 L98 76 L88 52 L88 112 L32 112 L32 52 L22 76 L8 70 Z',
jacket:'M26 20 L46 10 L60 22 L74 10 L94 20 L114 74 L100 80 L90 50 L90 112 L30 112 L30 50 L20 80 L6 74 Z',
cargo:'M34 8 H86 L94 112 H64 L60 52 L56 112 H26 Z'};
export default function ProductArt({type,color='Black',className=''}){const f=COLORS[color]||color;
return <svg viewBox="0 0 120 120" className={className} role="img" aria-label={`${color} ${type}`}>
<defs><linearGradient id={`g${type}`} x1="0" x2="1"><stop offset="0" stopColor="#fff" stopOpacity=".16"/><stop offset=".5" stopColor="#fff" stopOpacity="0"/><stop offset="1" stopColor="#000" stopOpacity=".35"/></linearGradient></defs>
<path d={P[type]} fill={f} stroke="#ffffff22" strokeWidth=".8"/><path d={P[type]} fill={`url(#g${type})`}/>
{type==='hoodie'&&<><path d="M46 12 Q60 40 74 12" fill="none" stroke="#0006" strokeWidth="2"/><rect x="44" y="82" width="32" height="14" rx="3" fill="#0003"/></>}
{type==='jacket'&&<><line x1="60" y1="22" x2="60" y2="112" stroke="#aaa8" strokeWidth="1.5"/><rect x="38" y="76" width="14" height="10" fill="#0003"/></>}
{type==='cargo'&&<><rect x="30" y="66" width="14" height="18" fill="#0004"/><rect x="76" y="66" width="14" height="18" fill="#0004"/></>}</svg>}
