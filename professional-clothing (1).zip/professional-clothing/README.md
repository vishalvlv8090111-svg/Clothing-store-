# PROFESSIONAL CLOTHING
React + Vite + Tailwind + React Three Fiber demo storefront.
## Run
    npm install
    npm run dev        # http://localhost:5173
    npm run build      # outputs /dist
## Deploy
Push to GitHub, import into Vercel or Netlify (build: `npm run build`, output: `dist`). Or `npm run build` and upload `dist/` to any static host.
## Before real sales
Checkout is a UI demo. Add a backend + payment gateway (Razorpay/Stripe): create orders server-side, validate prices on the server, confirm via webhooks, store orders in a database. Replace placeholder contact details and the Instagram link.
